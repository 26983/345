#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int Max(int a1, int b1);
int Mini(int a2, int b2);
int main()
{

	int a, b, Maximum, Minimum;
	printf("Enter two numbers:");
	scanf("%d%d", &a, &b);
	Maximum = Max(a, b);
	Minimum = Mini(a, b);
	return 0;
}
int Max(int a1, int b1)
{
	if (a1 > b1) {
		printf("The Maximum=%d\n", a1);
	}
	else {
		printf("The Maximum=%d\n", b1);
	}
}
int Mini(int a2, int b2)
{
	if (a2 < b2) {
		printf("The Minimum=%d", a2);
	}
	else {
		printf("The Minimum=%d", b2);
	}
}