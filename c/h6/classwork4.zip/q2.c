#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int fib(int n)
{
    if (n == 1)
        return 0;
    else if (n == 2)
        return 1;
    else
        return fib(n - 1) + fib(n - 2);
}

int main()
{
    int n;
    printf("Enter any number to find nth fibonacci term:");
    scanf("%d", &n);


    printf("The %dth fibonacci term is %d", n, fib(n));

    return 0;
}