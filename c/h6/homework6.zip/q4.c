#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int power(int n1, int n2);
int main() {
    double base,result;
    int a;
    printf("Enter base : ");
    scanf("%lf", &base);
    printf("Enter exponent: ");
    scanf("%d", &a);
    result = power(base, a);
    printf("%.2lf^%d = %lf", base, a, result);
    return 0;
}

int power(int base, int a) {
    if (a != 0)
        return (base * power(base, a - 1));
    else
        return 1;
}
